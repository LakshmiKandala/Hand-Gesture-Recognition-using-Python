# Hand-Web-Browser

## Output:
![](hand_web_browser.gif)
